package com.lti.dao;

import java.util.List;

import com.lti.model.Farmer;


public interface FarmerDao {
	public int createFarmer(Farmer farmer);
	/*public Student readStudentByRollNumber(int rollNumber);
	public int deleteStudentByRollNumber(int rollNumber);
	public int updateStudentByStudentName( int rollNumber,String studentName);
	public int updateStudentByStudentScore(int rollNumber, double studentScore);
	public List<Student> ViewAllStudents();
	*/
}
