package com.lti.service;



import com.lti.model.Farmer;


public interface FarmerService {
	public boolean addFarmer(Farmer farmer);
	/*public Student findStudentByRollNumber(int rollNumber);
	public int deleteStudentByRollNumber(int rollNumber);
	public int updateStudentByRollNumber(int rollNumber, String studentName);
	public int updateStudentByStudentScore(int rollNumber, double studentScore);
	public List<Student> ViewAllStudents();*/
}
