package com.lti.model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
@Component
@Entity
@Table(name = "DETAILSBIDDER")
public class DetailsBidder {

	@Id
	//@GeneratedValue
	@Column(name="bidder_details_id")
	private int bidderDetailsId;
	@Column(name="bidder_address")
	private String bidderAddressLine1;
//	@Column(name="bidder_address_line2")
//	private String bidderAddressLine2;
	@Column(name="bidder_city")
	private String bidderCity;
	@Column(name="bidder_state")
	private String bidderState;
	@Column(name="bidder_pincode")
	private int bidderPinCode;
	@Column(name="bidder_account_no")
	private int bidderAccountNo;
	@Column(name="bidder_ifsc_code")
	private String bidderIFSCCode;
	@Column(name="bidder_aadhar")
	private String bidderAadhaar;
	@Column(name="bidder_pan")
	private String bidderPan;
	@Column(name="bidder_trader_license")
	private String bidderTraderLicense;
	
	@OneToOne
	@JoinColumn(name = "bidder_details")
	Bidder bidderDetails;

	public DetailsBidder() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DetailsBidder(int bidderDetailsId, String bidderAddressLine1, String bidderCity, String bidderState,
			int bidderPinCode, int bidderAccountNo, String bidderIFSCCode, String bidderAadhaar, String bidderPan,
			String bidderTraderLicense, Bidder bidderDetails) {
		super();
		this.bidderDetailsId = bidderDetailsId;
		this.bidderAddressLine1 = bidderAddressLine1;
		this.bidderCity = bidderCity;
		this.bidderState = bidderState;
		this.bidderPinCode = bidderPinCode;
		this.bidderAccountNo = bidderAccountNo;
		this.bidderIFSCCode = bidderIFSCCode;
		this.bidderAadhaar = bidderAadhaar;
		this.bidderPan = bidderPan;
		this.bidderTraderLicense = bidderTraderLicense;
		this.bidderDetails = bidderDetails;
	}

	public int getBidderDetailsId() {
		return bidderDetailsId;
	}

	public void setBidderDetailsId(int bidderDetailsId) {
		this.bidderDetailsId = bidderDetailsId;
	}

	public String getBidderAddressLine1() {
		return bidderAddressLine1;
	}

	public void setBidderAddressLine1(String bidderAddressLine1) {
		this.bidderAddressLine1 = bidderAddressLine1;
	}

	public String getBidderCity() {
		return bidderCity;
	}

	public void setBidderCity(String bidderCity) {
		this.bidderCity = bidderCity;
	}

	public String getBidderState() {
		return bidderState;
	}

	public void setBidderState(String bidderState) {
		this.bidderState = bidderState;
	}

	public int getBidderPinCode() {
		return bidderPinCode;
	}

	public void setBidderPinCode(int bidderPinCode) {
		this.bidderPinCode = bidderPinCode;
	}

	public int getBidderAccountNo() {
		return bidderAccountNo;
	}

	public void setBidderAccountNo(int bidderAccountNo) {
		this.bidderAccountNo = bidderAccountNo;
	}

	public String getBidderIFSCCode() {
		return bidderIFSCCode;
	}

	public void setBidderIFSCCode(String bidderIFSCCode) {
		this.bidderIFSCCode = bidderIFSCCode;
	}

	public String getBidderAadhaar() {
		return bidderAadhaar;
	}

	public void setBidderAadhaar(String bidderAadhaar) {
		this.bidderAadhaar = bidderAadhaar;
	}

	public String getBidderPan() {
		return bidderPan;
	}

	public void setBidderPan(String bidderPan) {
		this.bidderPan = bidderPan;
	}

	public String getBidderTraderLicense() {
		return bidderTraderLicense;
	}

	public void setBidderTraderLicense(String bidderTraderLicense) {
		this.bidderTraderLicense = bidderTraderLicense;
	}

	public Bidder getBidderDetails() {
		return bidderDetails;
	}

	public void setBidderDetails(Bidder bidderDetails) {
		this.bidderDetails = bidderDetails;
	}

	@Override
	public String toString() {
		return "DetailsBidder [bidderDetailsId=" + bidderDetailsId + ", bidderAddressLine1=" + bidderAddressLine1
				+ ", bidderCity=" + bidderCity + ", bidderState=" + bidderState + ", bidderPinCode=" + bidderPinCode
				+ ", bidderAccountNo=" + bidderAccountNo + ", bidderIFSCCode=" + bidderIFSCCode + ", bidderAadhaar="
				+ bidderAadhaar + ", bidderPan=" + bidderPan + ", bidderTraderLicense=" + bidderTraderLicense
				+ ", bidderDetails=" + bidderDetails + "]";
	}

	
	
	
}
