package com.lti.dao;
import com.lti.model.DetailsBidder;


public interface BidderDao {
	public int addBidder(DetailsBidder bidder);

}
