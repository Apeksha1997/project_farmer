package com.lti.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.springframework.stereotype.Repository;

import com.lti.model.DetailsBidder;
@Repository
public class BidderDaoImpl implements BidderDao {

	
	@PersistenceContext
	private EntityManager entityManager;
	
	public BidderDaoImpl() {
	}
	@Override
	@Transactional
	public int addBidder(DetailsBidder bidder) {
		entityManager.persist(bidder);
		System.out.println("35314354");
		return 1;
	}

}
