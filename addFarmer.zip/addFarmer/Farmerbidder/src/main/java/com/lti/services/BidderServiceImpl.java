package com.lti.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.BidderDao;
import com.lti.model.DetailsBidder;

@Service("service1")
public class BidderServiceImpl implements BidderService {
	@Autowired
	private BidderDao dao;

	public BidderDao getDao() {
		return dao;
	}

	public void setDao(BidderDao dao) {
		this.dao = dao;
	}

	@Override
	public boolean addBidder(DetailsBidder bidder) {
		int result = dao.addBidder(bidder);
		if (result == 1)
			return true;
		else
			return false;
	}

}
