package com.lti.services;


import com.lti.model.DetailsBidder;


public interface BidderService {
	public boolean addBidder(DetailsBidder farmer);
}
